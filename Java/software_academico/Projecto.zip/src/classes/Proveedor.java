package classes;

public class Proveedor {


	private String id;
	private String nombre;
	private String direccion;
	private String tipoPago;
}
