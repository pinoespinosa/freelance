## Relevant articles:

- [A Guide to JGit](http://www.baeldung.com/jgit)
