## Relevant articles:

[Introduction to Animal Sniffer Maven Plugin](http://www.baeldung.com/maven-animal-sniffer)
