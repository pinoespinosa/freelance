package com.baeldung.apachecayenne.persistent;

import com.baeldung.apachecayenne.persistent.auto._Author;

public class Author extends _Author {

    private static final long serialVersionUID = 1L; 

}
