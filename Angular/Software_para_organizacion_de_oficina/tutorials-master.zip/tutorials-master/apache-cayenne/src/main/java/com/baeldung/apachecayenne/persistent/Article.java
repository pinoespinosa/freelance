package com.baeldung.apachecayenne.persistent;

import com.baeldung.apachecayenne.persistent.auto._Article;

public class Article extends _Article {

    private static final long serialVersionUID = 1L; 

}
