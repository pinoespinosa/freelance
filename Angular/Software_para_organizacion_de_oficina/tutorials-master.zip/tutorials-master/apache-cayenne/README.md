## Relevant articles:

- [Advanced Querying in Apache Cayenne](http://www.baeldung.com/apache-cayenne-query)
- [Introduction to Apache Cayenne ORM](http://www.baeldung.com/apache-cayenne-orm)
